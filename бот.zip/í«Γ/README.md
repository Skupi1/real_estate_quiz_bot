
## 9) Лид-опросник (Ростов-на-Дону)
Файл: `lead_quiz_bot.py`  
Отправляет заявки в чат `ADMIN_CHAT_ID`.

Запуск:
```bash
python lead_quiz_bot.py
```
